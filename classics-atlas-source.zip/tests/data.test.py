"""Source parser regressions and bibliographic data invariants."""
import json, sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from enrich import fields, normal
from merge_metadata import dates

class MetadataTests(unittest.TestCase):
    def test_empty_infobox_fields_do_not_swallow_next_field(self):
        f=fields('{{Infobox book\n| author =\n| genre = Novel\n| language = French\n| published = 1857\n}}')
        self.assertEqual(f['author'],'')
        self.assertEqual(f['genre'],'Novel')
        self.assertEqual(f['language'],'French')
    def test_original_date_not_later_edition(self):
        self.assertEqual(dates({'published':'1800 (English translation)'},'1568 book'),(1568,1568))
        self.assertEqual(dates({'published':'1871–1872'},''),(1871,1872))
        self.assertIsNone(dates({'published':'400 BC'},''))
        self.assertEqual(dates({'premiere_date':'{{circa|1595–96}}'},''),(1595,1596))
    def test_non_latin_author_names_do_not_collapse_to_empty(self):
        self.assertTrue(normal('Όμηρος'))
        self.assertNotEqual(normal('Όμηρος'),normal('Πλάτων'))
        self.assertEqual(normal('Charlotte Brontë'),normal('Charlotte Bronte'))
    def test_cover_and_edition_integrity(self):
        books=json.loads((ROOT/'data/catalog.json').read_text())
        for b in books:
            self.assertEqual(len(b['countries']),len(set(b['countries'])))
            if b.get('cover'):
                self.assertTrue(b['cover'].startswith('https://covers.openlibrary.org/b/id/'))
                self.assertTrue(b['coverSource'].startswith('https://openlibrary.org/'))
                self.assertTrue(b['provenance'])
            if b.get('pages'):
                self.assertTrue(b.get('edition'))
                self.assertTrue(0<b['pages']<20000)
            if b['start'] is not None:self.assertLessEqual(b['start'],b['end'])
    def test_coverage_matches_catalog(self):
        books=json.loads((ROOT/'data/catalog.json').read_text())
        c=json.loads((ROOT/'data/coverage.json').read_text())
        self.assertEqual(c['total'],len(books))
        self.assertEqual(c['covers'],sum(bool(b['cover']) for b in books))

if __name__=='__main__':unittest.main()
