// Minimal static host: only the public application, never source/cache files.
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),crypto=require('node:crypto');
const file=fs.readFileSync(path.join(__dirname,'dist/classics-atlas.html'));
const gzip=zlib.gzipSync(file),etag='"'+crypto.createHash('sha256').update(file).digest('hex').slice(0,24)+'"';
const server=http.createServer((req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,{'Allow':'GET, HEAD'});return res.end();}
  let pathname;try{pathname=new URL(req.url,'http://localhost').pathname;}catch{res.writeHead(400);return res.end('Bad request');}
  if(pathname==='/health'){res.writeHead(200,{'Content-Type':'text/plain'});return res.end(req.method==='HEAD'?'':'ok');}
  if(!['/','/index.html','/classics-atlas.html'].includes(pathname)){res.writeHead(404,{'Content-Type':'text/plain'});return res.end('Not found');}
  res.setHeader('ETag',etag);res.setHeader('Cache-Control','public, max-age=0, must-revalidate');res.setHeader('Vary','Accept-Encoding');
  if(req.headers['if-none-match']===etag){res.writeHead(304);return res.end();}
  const compress=/\bgzip\b/.test(req.headers['accept-encoding']||'');const body=compress?gzip:file;
  if(compress)res.setHeader('Content-Encoding','gzip');
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Length':body.length});res.end(req.method==='HEAD'?undefined:body);
});
server.listen(Number(process.env.PORT)||3000,'0.0.0.0',()=>console.log('Classics Atlas listening on',server.address().port));
process.on('SIGTERM',()=>server.close(()=>process.exit(0)));
