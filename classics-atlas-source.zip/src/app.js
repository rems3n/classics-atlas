/* Classics Atlas: dependency-free application UI over bundled D3. */
(()=>{'use strict';
const C=AtlasCore,books=ATLAS_DATA.books,world=ATLAS_DATA.world,byId=new Map(books.map(b=>[b.id,b]));
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icons={book:'M3 4h6a4 4 0 0 1 3 2 4 4 0 0 1 3-2h6v15h-6a4 4 0 0 0-3 2 4 4 0 0 0-3-2H3zM12 6v15',shelf:'M4 3v18M9 3v18M14 3v18M18 3l4 17',search:'M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0',arrow:'M5 12h14M13 6l6 6-6 6',share:'M12 16V3M7 8l5-5 5 5M5 13v7h14v-7',moon:'M20 14A9 9 0 0 1 10 3a9 9 0 1 0 10 11',sun:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1 1M18 18l1 1M5 19l1-1M18 6l1-1',info:'M12 11v6M12 7v1M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',chevron:'M6 9l6 6 6-6',close:'M6 6l12 12M6 18L18 6',plus:'M12 5v14M5 12h14',minus:'M5 12h14',locate:'M12 2v4M12 18v4M2 12h4M18 12h4M19 12a7 7 0 1 1-14 0 7 7 0 0 1 14 0',reset:'M3 4v6h6M3 10a9 9 0 1 1 2 9',expand:'M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5',filter:'M3 6h18M6 12h12M9 18h6'};
const icon=k=>`<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="${icons[k]||icons.book}"/></svg>`;
function applyIcons(){document.querySelectorAll('[data-icon]').forEach(e=>e.innerHTML=icon(e.dataset.icon));document.querySelectorAll('[data-icon-label]').forEach(e=>{if(!e.querySelector('svg'))e.insertAdjacentHTML('afterbegin',icon(e.dataset.iconLabel));});}
applyIcons();
function storageGet(k,f){try{return JSON.parse(localStorage.getItem(k))??f;}catch{return f;}}
let storageWarning=false;
function storageSet(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch{if(!storageWarning){storageWarning=true;toast('Browser storage is unavailable. Export a backup to keep your shelf.');}}}
function cleanShelf(raw){const out={};if(!raw||typeof raw!=='object')return out;for(const [id,v]of Object.entries(raw))if(byId.has(id)&&v&&typeof v==='object'){const status=['want','reading','read'].includes(v.status)?v.status:'';const rating=Number.isInteger(v.rating)&&v.rating>=0&&v.rating<=5?v.rating:0;if(status||rating)out[id]={status:status||'want',rating};}return out;}
let shelf=cleanShelf(storageGet('classics-atlas-shelf-v1',{}));
let state=C.decode(location.hash)||C.defaults(),previous=null,limit=30,filtered=[],mapBooks=[],countryCounts={},mapTransform=d3.zoomIdentity,projection,path,width,height,rotation=[-10,-20,0],globeScale=1,detailId=null;
let resultsOpen=innerWidth>700,filtersOpen=false;
const theme=storageGet('classics-atlas-theme','light');document.documentElement.dataset.theme=theme==='dark'?'dark':'light';
document.body.classList.toggle('reduced-glass',storageGet('classics-atlas-reduced-glass',false));$('reduceGlass').checked=document.body.classList.contains('reduced-glass');
const mapPlaces=[...world.features,...(ATLAS_DATA.places||[]).map(p=>({id:p.id,properties:{name:p.name,label:p.label}}))];
const names=new Map(mapPlaces.map(f=>[f.id,f.properties.name]));
const languages=[...new Set(books.map(b=>b.language).filter(Boolean))].sort();
const traditions=[...new Set(books.map(b=>b.tradition).filter(Boolean))].sort();
for(const [id,values]of [['traditionSelect',traditions],['languageSelect',languages],['collectionSelect',[...new Set(books.flatMap(b=>b.collections||[]))].sort()]])$(id).insertAdjacentHTML('beforeend',values.map(v=>`<option>${esc(v)}</option>`).join(''));
$('countrySelect').insertAdjacentHTML('beforeend',[...names].sort((a,b)=>a[1].localeCompare(b[1])).map(([id,n])=>`<option value="${id}">${esc(n)}</option>`).join(''));
$('categoryChoices').innerHTML=C.categories.map((c,i)=>`<label class="category-row"><input type="checkbox" value="${esc(c)}"><span>${esc(c)}</span><span class="dot" style="background:${C.colors[i]}"></span><span class="cat-count">${books.filter(b=>b.categories.includes(c)).length}</span></label>`).join('');
function toast(message){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,4500);}
function change(patch,{keepScroll=false}={}){state=C.sanitize({...state,...patch});limit=30;render();if(!keepScroll)$('bookList').scrollTop=0;}
function updateHash(){try{history.replaceState(null,'',C.encode(state));}catch{}}
window.addEventListener('hashchange',()=>{const s=C.decode(location.hash);if(s){state=s;render();}});
function render(){
 filtered=books.filter(b=>C.matches(b,state,shelf));mapBooks=books.filter(b=>C.matches(b,state,shelf,true));countryCounts=C.counts(mapBooks);
 document.body.classList.remove('books-view','shelf-view','timeline-view');if(state.view!=='map')document.body.classList.add(state.view+'-view');
 syncPanels();
 document.querySelectorAll('[data-view]').forEach(e=>e.classList.toggle('active',e.dataset.view===state.view));
 document.querySelectorAll('[data-type]').forEach(e=>e.classList.toggle('active',e.dataset.type===state.type));
 document.querySelectorAll('#categoryChoices input').forEach(e=>e.checked=state.categories.includes(e.value));
 for(const [id,key]of [['collectionSelect','collection'],['traditionSelect','tradition'],['languageSelect','language'],['countrySelect','country'],['colorSelect','color'],['sortSelect','sort']])$(id).value=state[key];
 for(const [id,key]of [['overlayToggle','overlay'],['unknownToggle','includeUnknown'],['emptyToggle','hideEmpty']])$(id).checked=state[key];
 $('flatBtn').classList.toggle('active',state.projection==='map');$('globeBtn').classList.toggle('active',state.projection==='globe');
 $('themeBtn').innerHTML=icon(document.documentElement.dataset.theme==='dark'?'sun':'moon');
 $('shelfTabs').hidden=state.view!=='shelf';document.querySelectorAll('[data-shelf]').forEach(e=>e.classList.toggle('active',e.dataset.shelf===state.shelf));
 $('shelfCount').textContent=Object.keys(shelf).length;
 $('resultsKicker').textContent=state.view==='shelf'?'YOUR READING JOURNEY':'THE COLLECTION';
 $('resultsTitle').textContent=state.view==='shelf'?'My shelf':state.country?names.get(state.country)||state.country:state.tradition!=='All'?state.tradition:'Around the world';
 const placed=filtered.filter(b=>b.countries.length).length;
 $('resultCount').textContent=filtered.length.toLocaleString()+' matching '+(filtered.length===1?'work':'works')+' · '+placed+' with location data';
 $('coverageLabel').textContent=books.filter(b=>b.start!=null).length+' dates / ranges · '+books.filter(b=>b.cover).length+' covers';
 $('dataStatus').textContent=books.length.toLocaleString()+' catalog works · '+books.filter(b=>b.countries.length).length+' geographically annotated';
 $('clearPlace').hidden=!state.country;
 renderChips();renderBooks();renderTimeline();resize();renderLegend();updateHash();
}
function renderChips(){const chips=[];
 if(state.collection!=='All')chips.push(['collection',state.collection]);if(state.tradition!=='All')chips.push(['tradition',state.tradition]);if(state.language!=='All')chips.push(['language',state.language]);if(state.country)chips.push(['country',names.get(state.country)]);if(state.type!=='All')chips.push(['type',state.type]);for(const cat of state.categories)chips.push(['category',cat]);if(state.q)chips.push(['q',state.q]);if(state.from!==-2500||state.to!==2050)chips.push(['date',state.before?'Before '+C.year(state.to):C.year(state.from)+' – '+C.year(state.to)]);
 $('chips').innerHTML=chips.map(([key,val])=>`<button class="chip" data-chip="${key}" data-value="${esc(val)}" aria-label="Remove ${esc(val)} filter">${esc(val)} <span class="x">×</span></button>`).join('');}
const failedCovers=new Set();
document.addEventListener('error',e=>{if(e.target.matches?.('img.edition-cover')){failedCovers.add(e.target.dataset.coverId);const parent=e.target.parentElement;parent.classList.remove('has-cover');parent.setAttribute('aria-label','Cover unavailable; title-art placeholder');e.target.remove();}},true);
function cover(b){const actual=(b.cover?.startsWith('https://covers.openlibrary.org/b/id/')||b.coverProvider==='Publisher'&&b.cover?.startsWith('https://'))&&!failedCovers.has(b.id);return `<div class="cover ${actual?'has-cover':''}" style="--cover-color:${C.colors[Math.max(0,C.categories.indexOf(b.categories[0]))]}" role="img" aria-label="${actual?esc(b.coverLabel+' for '+b.title):'Title-art placeholder for '+esc(b.title)+'; not an actual edition cover'}"><small>CLASSICS ATLAS</small><span>${esc(b.title.length>44?b.title.slice(0,41)+'…':b.title)}</span><small>${b.cover?'COVER UNAVAILABLE':'TITLE ART'}</small>${actual?`<img class="edition-cover" data-cover-id="${b.id}" src="${esc(b.cover)}" alt="${esc(b.title)} — ${esc(b.coverLabel)}" loading="lazy" decoding="async" referrerpolicy="no-referrer">`:''}</div>`;}
function stars(b){return `<div class="stars" role="group" aria-label="Your rating of ${esc(b.title)}">${[1,2,3,4,5].map(n=>`<button data-rate="${b.id}" data-rating="${n}" class="${(shelf[b.id]?.rating||0)>=n?'filled':''}" aria-label="Rate ${n} ${n===1?'star':'stars'}" aria-pressed="${(shelf[b.id]?.rating||0)===n}">${(shelf[b.id]?.rating||0)>=n?'★':'☆'}</button>`).join('')}</div>`;}
function shelfSelect(b){return `<select data-status="${b.id}" aria-label="Reading status for ${esc(b.title)}">${[['',shelf[b.id]?'Remove from shelf':'Add to shelf'],['want','Want to read'],['reading','Reading'],['read','Read']].map(([v,n])=>`<option value="${v}" ${(shelf[b.id]?.status||'')===v?'selected':''}>${n}</option>`).join('')}</select>`;}
function card(b){return `<article class="book-card" data-book="${b.id}"><div class="book-main">${cover(b)}<div class="book-copy"><button class="book-title" data-detail="${b.id}">${esc(b.title)}</button><div class="author">${esc(b.author)}</div><div class="book-meta">${b.textDate?`<span class="date-basis">${b.dateKind==='original composition'?'Composition':'Story origins'} · </span>`:''}${esc(C.date(b))}</div>${b.categories.map(c=>`<span class="tag">${esc(c)}</span>`).join('')}${b.start==null?'<span class="tag">Metadata pending</span>':''}<p class="book-summary">${esc(b.overview||'Included in the Penguin Classics source list. Date, location, category, and edition details still need enrichment.')}</p></div></div><div class="book-actions">${shelfSelect(b)}<button data-detail="${b.id}">Book details ↗</button></div><div class="rating-row"><span>Your rating</span>${stars(b)}</div></article>`;}
function sorted(){return [...filtered].sort((a,b)=>{if(state.sort==='title')return a.title.localeCompare(b.title);if(state.sort==='rating')return (shelf[b.id]?.rating||0)-(shelf[a.id]?.rating||0)||a.title.localeCompare(b.title);if(a.start==null||b.start==null)return (a.start==null)-(b.start==null)||a.title.localeCompare(b.title);if(state.sort==='newest')return b.start-a.start;return a.start-b.start||a.title.localeCompare(b.title);});}
function renderBooks(){const list=sorted();$('bookList').innerHTML=list.length?list.slice(0,limit).map(card).join('')+(list.length>limit?`<button class="load-more" id="loadMore">Show 30 more · ${list.length-limit} remaining</button>`:''):`<div class="empty"><span data-icon="book"></span><h3>${state.view==='shelf'?'A story waiting to begin.':'No works in this view.'}</h3><p>${state.view==='shelf'?'Add books to your shelf or widen your filters. Your ratings and progress stay on this device.':'Try a wider date range or fewer filters. This region may not have location metadata yet; an empty map does not mean no literature exists here.'}</p><button data-action="reset">${state.view==='shelf'?'Explore books':'Reset filters'}</button></div>`;}
const eras={all:[-2500,2050],ancient:[-2500,500],medieval:[500,1500],renaissance:[1400,1700],modern:[1800,2050]};
const timelineBrush=$('timelineBrush');let timelineGesture=null,timelineKeyboardYear=null;
const yearPercent=y=>(y+2500)/4550*100;
$('timelineTicks').innerHTML=Array.from({length:92},(_,i)=>{const y=i*50-2500,major=y%500===0;return `<span class="time-tick ${major?'major':''} ${y===-2500?'first':y===2000?'last':''}" style="left:${yearPercent(y)}%">${major?`<small>${y===0?'BC / AD':y<0?Math.abs(y)+' BC':y}</small>`:''}</span>`;}).join('');
function paintTimelineRange(range){
 $('dateRange').textContent=C.year(range.from)+' — '+C.year(range.to);
 $('timelineSelection').style.left=yearPercent(range.from)+'%';
 $('timelineSelection').style.width=(range.to-range.from)/4550*100+'%';
 for(const [id,key]of [['fromRange','from'],['fromNumber','from'],['toRange','to'],['toNumber','to']])$(id).value=range[key];
 $('histogram').querySelectorAll('.hist-bar').forEach((bar,i)=>bar.classList.toggle('outside',i*50-2500<range.from||i*50-2500>range.to));
}
function timelineYearAt(clientX){const rect=timelineBrush.getBoundingClientRect();return C.snapYear(-2500+(clientX-rect.left)/Math.max(1,rect.width)*4550);}
function showTimelineYear(y){$('timelineHover').hidden=false;$('timelineHover').textContent=C.year(y);$('timelineHover').style.left=Math.max(8,Math.min(92,yearPercent(y)))+'%';}
function finishTimelineGesture(cancel=false){
 const g=timelineGesture;if(!g)return;timelineGesture=null;timelineBrush.classList.remove('selecting');
 if(timelineBrush.hasPointerCapture?.(g.id))timelineBrush.releasePointerCapture(g.id);
 $('timelineHover').hidden=true;
 if(cancel)paintTimelineRange(state);
 else change({...C.timelineSelection(g.anchor,g.end,g.drag),before:false,after:false,includeUnknown:false},{keepScroll:true});
}
timelineBrush.addEventListener('pointerdown',e=>{
 if(e.button!==0||e.isPrimary===false||timelineGesture)return;e.preventDefault();
 timelineBrush.focus({preventScroll:true});const year=timelineYearAt(e.clientX);
 timelineGesture={id:e.pointerId,x:e.clientX,anchor:year,end:year,drag:false};timelineKeyboardYear=year;
 timelineBrush.setPointerCapture?.(e.pointerId);timelineBrush.classList.add('selecting');
 showTimelineYear(year);paintTimelineRange(C.timelineSelection(year,year));
});
timelineBrush.addEventListener('pointermove',e=>{
 const y=timelineYearAt(e.clientX),g=timelineGesture;if(g&&g.id!==e.pointerId)return;
 showTimelineYear(y);
 if(g){g.end=y;g.drag=g.drag||(Math.abs(e.clientX-g.x)>=4&&y!==g.anchor);paintTimelineRange(C.timelineSelection(g.anchor,y,g.drag));}
});
timelineBrush.addEventListener('pointerup',e=>{if(timelineGesture?.id!==e.pointerId)return;timelineGesture.end=timelineYearAt(e.clientX);timelineGesture.drag=timelineGesture.drag||(Math.abs(e.clientX-timelineGesture.x)>=4&&timelineGesture.end!==timelineGesture.anchor);finishTimelineGesture();});
timelineBrush.addEventListener('pointercancel',e=>{if(timelineGesture?.id===e.pointerId)finishTimelineGesture(true);});
timelineBrush.addEventListener('lostpointercapture',e=>{if(timelineGesture?.id===e.pointerId)finishTimelineGesture(true);});
timelineBrush.addEventListener('pointerleave',()=>{if(!timelineGesture)$('timelineHover').hidden=true;});
timelineBrush.addEventListener('focus',()=>{timelineKeyboardYear=C.snapYear((state.from+state.to)/2);});
timelineBrush.addEventListener('blur',()=>{finishTimelineGesture(true);$('timelineHover').hidden=true;});
timelineBrush.addEventListener('keydown',e=>{
 if(e.key==='Escape'){e.preventDefault();finishTimelineGesture(true);$('timelineHover').hidden=true;return;}
 if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();timelineKeyboardYear=C.snapYear(e.key==='Home'?-2500:e.key==='End'?2050:(timelineKeyboardYear??0)+(e.key==='ArrowLeft'?-50:50));showTimelineYear(timelineKeyboardYear);}
 if(e.key==='Enter'||e.key===' '){e.preventDefault();if(timelineGesture)return;const y=timelineKeyboardYear??C.snapYear((state.from+state.to)/2);change({...C.timelineSelection(y,y),before:false,after:false,includeUnknown:false},{keepScroll:true});showTimelineYear(y);}
});
function renderTimeline(){
 $('dateRange').textContent=C.year(state.from)+' — '+C.year(state.to);
 for(const [id,key]of [['fromRange','from'],['fromNumber','from'],['toRange','to'],['toNumber','to']])$(id).value=state[key];
 document.querySelectorAll('[data-era]').forEach(e=>{const r=eras[e.dataset.era];e.classList.toggle('active',r[0]===state.from&&r[1]===state.to);});
 const binBooks=books.filter(b=>C.matches(b,{...state,from:-2500,to:2050,before:false,after:false},shelf));const bins=Array.from({length:91},()=>0);
 for(const b of binBooks)if(b.start!=null){const i=Math.floor((b.start+2500)/50);if(i>=0&&i<bins.length)bins[i]++;}
 const max=Math.max(1,...bins);$('histogram').innerHTML=bins.map((v,i)=>`<div class="hist-bar ${i*50-2500<state.from||i*50-2500>state.to?'outside':''}" style="height:${v?Math.max(8,Math.sqrt(v/max)*100):2}%" title="${C.year(i*50-2500)}: ${v} works"></div>`).join('');
 paintTimelineRange(state);
 $('timelineList').hidden=state.view!=='timeline';if(state.view==='timeline'){const groups={};for(const b of filtered)if(b.start!=null)(groups[Math.floor(b.start/50)*50]??=[]).push(b);$('timelineList').innerHTML=Object.keys(groups).sort((a,b)=>a-b).map(y=>`<div class="timeline-group"><strong>${esc(C.year(+y))}</strong><div>${groups[y].map(b=>`<button data-detail="${b.id}">${esc(b.title)} <span>— ${esc(b.author)} · ${esc(C.date(b))}</span></button>`).join('')}</div></div>`).join('')||'<div class="empty"><h3>No dated works in this view</h3><p>Try widening your filters.</p></div>';}}
const svg=d3.select('#map');let mapGroup=svg.append('g'),grid=mapGroup.append('path').attr('class','graticule'),land=mapGroup.append('g'),culture=mapGroup.append('g'),labels=mapGroup.append('g'),marks=mapGroup.append('g');
const countryPaths=land.selectAll('path').data(world.features).join('path').attr('class','country').attr('data-country',d=>d.id).on('click',(e,f)=>{if(e.defaultPrevented)return;change({country:f.id,view:'map'});showResults();}).on('mousemove',(e,f)=>{const count=countryCounts[f.id]?.length||0;$('tooltip').innerHTML=`<strong>${esc(f.properties.name)}</strong><span>${count} matching works with location data</span>`;$('tooltip').hidden=false;$('tooltip').style.left=Math.min(e.clientX+14,window.innerWidth-230)+'px';$('tooltip').style.top=Math.max(10,e.clientY-55)+'px';}).on('mouseleave',()=>$('tooltip').hidden=true);
const zoom=d3.zoom().scaleExtent([.8,12]).filter(e=>state.projection==='map'&&(!e.ctrlKey||e.type==='wheel')&&!e.button).on('zoom',e=>{mapTransform=e.transform;mapGroup.attr('transform',mapTransform);positionMarkers();});svg.call(zoom).on('dblclick.zoom',null);
let dragOrigin=null;
svg.on('pointerdown.globe',e=>{if(state.projection==='globe'){dragOrigin=[e.clientX,e.clientY,...rotation];}}).on('pointermove.globe',e=>{if(dragOrigin&&state.projection==='globe'){rotation=[dragOrigin[2]+(e.clientX-dragOrigin[0])*.25,Math.max(-85,Math.min(85,dragOrigin[3]-(e.clientY-dragOrigin[1])*.25)),0];projection.rotate(rotation);paintGeometry();}}).on('pointerup.globe pointerleave.globe',()=>dragOrigin=null);
function resize(){const w=$('mapCanvas').clientWidth,h=$('mapCanvas').clientHeight;if(!w||!h)return;width=w;height=h;svg.attr('viewBox',`0 0 ${width} ${height}`);renderMap();}
function colorFor(list){if(!list?.length)return 'var(--land)';if(state.color==='count'){const max=Math.max(1,...Object.values(countryCounts).map(a=>a.length));return d3.interpolateRgb(document.documentElement.dataset.theme==='dark'?'#345460':'#bdd9d2',document.documentElement.dataset.theme==='dark'?'#55aeaa':'#488f8a')(.18+.82*Math.sqrt(list.length/max));}if(state.color==='category'){const c=d3.rollups(list,b=>b.length,b=>b.categories[0]||'Unknown').sort((a,b)=>b[1]-a[1])[0][0];return C.colors[C.categories.indexOf(c)]||'#76999c';}if(state.color==='era'){const y=Math.min(...list.map(b=>b.start??3000));return y<500?'#468f95':y<1500?'#8f89b9':y<1800?'#9f789d':'#688ab2';}const l=d3.rollups(list,b=>b.length,b=>b.language).sort((a,b)=>b[1]-a[1])[0][0];return C.colors[languages.indexOf(l)%10];}
function renderMap(){if(!width)return;
 if(state.projection==='globe'){projection=d3.geoOrthographic().rotate(rotation).scale(Math.min(width*.44,height*.44)*globeScale).translate([width*.5,height*.48]);mapGroup.attr('transform',null);}else{projection=d3.geoEqualEarth().fitExtent([[20,18],[Math.max(40,width-20),Math.max(50,height-60)]],{type:'Sphere'});mapGroup.attr('transform',mapTransform);}
 path=d3.geoPath(projection);countryPaths.attr('fill',f=>colorFor(countryCounts[f.id])).classed('selected',f=>f.id===state.country);
 countryPaths.attr('visibility',f=>state.hideEmpty&&!(countryCounts[f.id]?.length)?'hidden':'visible');
 paintGeometry();}
function paintGeometry(){countryPaths.attr('d',path);grid.attr('d',path(d3.geoGraticule10()));
 const greek=state.overlay&&state.tradition==='Ancient Greek';culture.selectAll('*').remove();if(greek){const shape=d3.geoCircle().center([25.5,38]).radius(5)();culture.append('path').attr('class','culture-shape').attr('d',path(shape));const p=projection([25.5,32]);culture.append('text').attr('class','culture-label').attr('x',p[0]).attr('y',p[1]).text('Aegean cultural lens · schematic');}
 positionMarkers();}
function visiblePoint(coords){return state.projection!=='globe'||d3.geoDistance(coords,[-rotation[0],-rotation[1]])<Math.PI/2;}
function positionMarkers(){if(!projection)return;const k=state.projection==='map'?mapTransform.k:1;
 const features=mapPlaces.filter(f=>countryCounts[f.id]?.length&&visiblePoint(f.properties.label)).sort((a,b)=>countryCounts[b.id].length-countryCounts[a.id].length);
 const clusters=[];
 for(const f of features){const point=projection(f.properties.label);const nearby=clusters.find(c=>Math.hypot((c.point[0]-point[0])*k,(c.point[1]-point[1])*k)<34);if(nearby)nearby.features.push(f);else clusters.push({id:f.id,point,features:[f]});}
 for(const c of clusters)c.count=new Set(c.features.flatMap(f=>countryCounts[f.id].map(b=>b.id))).size;
 function activate(e,c){e.stopPropagation();$('tooltip').hidden=true;if(c.features.length===1){change({country:c.features[0].id,view:'map'});showResults();}else if(state.projection==='globe'){const coords=c.features[0].properties.label;rotation=[-coords[0],-coords[1],0];globeScale=Math.min(3,globeScale*1.7);renderMap();}else svg.transition().duration(250).call(zoom.scaleBy,1.8,mapTransform.apply(c.point));}
 marks.selectAll('g').data(clusters,c=>c.id).join(enter=>{const g=enter.append('g').attr('role','button').attr('tabindex',0);g.append('circle');g.append('text');return g;}).attr('class',c=>'marker'+(c.features.length>1?' cluster-marker':'')).attr('transform',c=>`translate(${c.point}) scale(${1/k})`).attr('aria-label',c=>(c.features.length>1?c.features.length+' nearby places; zoom to separate':c.features[0].properties.name)+': '+c.count+' unique works').on('click',activate).on('keydown',(e,c)=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();activate(e,c);}}).on('mousemove',(e,c)=>{$('tooltip').innerHTML=`<strong>${c.features.map(f=>esc(f.properties.name)).join(' · ')}</strong><span>${c.count} unique matching works${c.features.length>1?' · Click to zoom':''}</span>`;$('tooltip').hidden=false;$('tooltip').style.left=Math.max(8,Math.min(e.clientX+12,innerWidth-245))+'px';$('tooltip').style.top=Math.max(8,e.clientY-65)+'px';}).on('mouseleave',()=>$('tooltip').hidden=true).each(function(c){d3.select(this).select('circle').attr('r',c.features.length>1?15:12);d3.select(this).select('text').text(c.count);});
 // Keep dense labels out of the way at overview scale; details remain on hover.
 const labelScale=state.projection==='globe'?globeScale:k;
 const candidates=mapPlaces.filter(f=>visiblePoint(f.properties.label)&&(!state.hideEmpty||countryCounts[f.id]?.length)&&(f.id===state.country||(labelScale>1.8&&countryCounts[f.id]?.length)||['CAN','BRA','AUS','CHN','IND','RUS','ZAF','EGY'].includes(f.id)));
 candidates.sort((a,b)=>(b.id===state.country)-(a.id===state.country));
 const occupied=[],labelFeatures=candidates.filter(f=>{const p=projection(f.properties.label),x=p[0]*k,y=p[1]*k+28,half=Math.min(100,f.properties.name.length*3.2);if(occupied.some(r=>Math.abs(x-r.x)<half+r.half+8&&Math.abs(y-r.y)<18))return false;occupied.push({x,y,half});return true;});
 labels.selectAll('text').data(labelFeatures,f=>f.id).join('text').attr('class','country-label').attr('transform',f=>`translate(${projection(f.properties.label)}) scale(${1/k})`).attr('text-anchor','middle').attr('dy',f=>countryCounts[f.id]?.length?28:0).text(f=>f.properties.name.toUpperCase());}
function renderLegend(){let html='<div class="legend-title">'+({count:'MATCHING WORKS',category:'LEADING CATEGORY',era:'EARLIEST WORK',language:'LEADING LANGUAGE'}[state.color])+'</div><div class="legend-row">';if(state.color==='count')html+='<span>1</span><span class="legend-gradient"></span><span>'+Math.max(1,...Object.values(countryCounts).map(a=>a.length))+'</span>';else if(state.color==='category')html+=C.categories.filter(c=>mapBooks.some(b=>b.categories.includes(c))).map(c=>`<button data-legend-cat="${esc(c)}"><i class="swatch" style="background:${C.colors[C.categories.indexOf(c)]}"></i>${esc(c)}</button>`).join('');else if(state.color==='era')html+=[['Ancient','#468f95'],['Medieval','#8f89b9'],['Early modern','#9f789d'],['Modern','#688ab2']].map(([s,c])=>`<span class="swatch" style="background:${c}"></span><span>${s}</span>`).join('');else html+=languages.filter(l=>mapBooks.some(b=>b.language===l)).map(l=>`<span class="swatch" style="background:${C.colors[languages.indexOf(l)%10]}"></span><span>${esc(l)}</span>`).join('');$('legend').innerHTML=html+'</div>';}
function syncPanels(){
 const contentView=state.view==='books'||state.view==='shelf';
 const visible=resultsOpen||contentView;
 document.body.classList.toggle('results-closed',!visible);
 document.body.classList.toggle('filters-open',filtersOpen);
 $('results').hidden=!visible;$('openResults').hidden=visible;$('filters').hidden=!filtersOpen;
 $('mobileFilters').setAttribute('aria-expanded',String(filtersOpen));
 $('filters').classList.toggle('mobile-open',filtersOpen&&innerWidth<=700);
}
function showResults(){resultsOpen=true;syncPanels();resize();}
function setFilters(open){filtersOpen=open;syncPanels();resize();}
function dateHistory(b){
 if(!b.textDate)return '';
 const layers=b.dateLayers||[];
 return `<section class="date-history"><h3>Story origins and later versions</h3><p><strong>${esc(b.textDate.label)}</strong><br>${esc(C.date(b.textDate))} <span class="muted">· reference only; the timeline uses the main date above</span></p>${layers.length?`<h4>Stories and source traditions</h4><p class="muted">A partial breakdown of the volume’s different layers. These are estimates or early attestations, not proven first tellings. The map counts the whole volume once.</p><ul class="origin-layers">${layers.map(x=>`<li><strong>${esc(x.title)}</strong><div>${x.start==null?'Origin not securely dated':esc(C.date({...x,dateConfidence:'estimated'}))}</div><p>${esc(x.note)}</p><div class="button-row">${x.start!=null?`<button data-origin-from="${x.start}" data-origin-to="${x.end}">Explore this period</button>`:''}${x.sources.map(url=>`<a href="${esc(url)}" target="_blank" rel="noopener">Source ↗</a>`).join('')}</div></li>`).join('')}</ul>`:''}</section>`;
}
function showDetail(id){const b=byId.get(id);if(!b)return;detailId=id;const ed=b.edition;
 $('detailContent').innerHTML=`<span class="eyebrow">BOOK NOTES</span><div class="detail-head">${cover(b)}<div><h2>${esc(b.title)}</h2><p>${esc(b.author)}</p>${b.categories.map(c=>`<span class="tag">${esc(c)}</span>`).join('')}</div></div><p style="margin-top:22px">${esc(b.overview||'Descriptive metadata is not available yet.')}</p><dl class="detail-data"><div><dt>${esc(b.dateKind||'Original publication / composition')}</dt><dd>${esc(C.date(b))}${b.dateNote?`<small>${esc(b.dateNote)}</small>`:''}</dd></div><div><dt>Collection</dt><dd>${(b.collections||[]).map(esc).join(" · ")}</dd></div>${b.aliases?.length?`<div><dt>Also searchable as</dt><dd>${b.aliases.map(esc).join(" · ")}</dd></div>`:""}<div><dt>Original language</dt><dd>${esc(b.language||'Unknown')}</dd></div><div><dt>Geographic association</dt><dd>${esc(b.location||'Unknown')}${b.locationNote?`<small>${esc(b.locationNote)}</small>`:''}</dd></div><div><dt>Literary tradition</dt><dd>${esc(b.tradition||'Unknown')}</dd></div><div><dt>Page length · selected edition</dt><dd>${b.pages?esc(b.pages)+' pages':'Unknown — edition not verified'}</dd></div><div><dt>Goodreads score</dt><dd>Unavailable — not connected</dd></div></dl>${dateHistory(b)}<div class="book-actions">${shelfSelect(b)}${stars(b)}</div>
 ${b.cover?`<h3>Cover & selected edition</h3><p><a href="${esc(b.coverSource)}" target="_blank" rel="noopener">${esc(b.coverLabel)} · ${esc(b.coverProvider||"Open Library")} ↗</a>${ed?`<br>${esc((ed.publisher||[]).join(', '))} · ${esc((ed.publish_date||[]).join(', '))}${ed.isbn?.length?'<br>ISBN '+esc(ed.isbn.join(' / ')):''}`:''}</p><p class="muted">${b.coverProvider==='Publisher'?'Cover linked from the publisher’s product page.':'Automated title/author match. An alternate edition is labeled explicitly; publisher family does not guarantee the Classics imprint.'} Artwork may differ between printings.</p>`:'<p class="detail-note">No confident online cover match. The artwork shown is a labeled title placeholder.</p>'}
 <details class="source-notes"><summary>Metadata sources & uncertainty</summary><p>Automated imports and editorial annotations need review. Locations use documented author associations, origin, or explicitly labeled work-tradition fallbacks. ${esc(b.overviewNote||'')}</p>${(b.provenance||[]).map(p=>`<p><strong>${esc(p.fields)}</strong><br>${esc(p.method)}<br><a href="${esc(p.source)}" target="_blank" rel="noopener">View source ↗</a></p>`).join('')}</details><h3>Source catalog entries / editions</h3><p>${b.editions.map(esc).join('<br>')}</p><div class="button-row"><a href="${esc(b.source)}" target="_blank" rel="noopener">Work reference ↗</a><a href="https://www.goodreads.com/search?q=${encodeURIComponent(b.title+' '+b.author)}" target="_blank" rel="noopener">Find on Goodreads ↗</a><a href="https://www.penguin.co.uk/search-results?q=${encodeURIComponent(b.title)}" target="_blank" rel="noopener">Find a Penguin edition ↗</a></div>`;if(!$('detailDialog').open)$('detailDialog').showModal();}
function saveShelf(){storageSet('classics-atlas-shelf-v1',shelf);const scroll=$('bookList').scrollTop;render();$('bookList').scrollTop=scroll;if($('detailDialog').open)showDetail(detailId);}
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
 if(b.dataset.originFrom!==undefined){$('detailDialog').close();change({from:+b.dataset.originFrom,to:+b.dataset.originTo,before:false,after:false,includeUnknown:false});return;}
 if(b.dataset.detail){showDetail(b.dataset.detail);return;}
 if(b.dataset.rate){const id=b.dataset.rate,n=+b.dataset.rating;shelf[id]??={status:'want',rating:0};shelf[id].rating=shelf[id].rating===n?0:n;saveShelf();return;}
 if(b.dataset.close){$(b.dataset.close).close();return;}
 if(b.dataset.view){change({view:b.dataset.view});showResults();return;}
 if(b.dataset.type){change({type:b.dataset.type});return;}
 if(b.dataset.era){const [from,to]=eras[b.dataset.era];change({from,to,includeUnknown:b.dataset.era==='all',before:false,after:false});return;}
 if(b.dataset.shelf){change({shelf:b.dataset.shelf});return;}
 if(b.dataset.legendCat){change({categories:[b.dataset.legendCat]});return;}
 if(b.dataset.chip){const key=b.dataset.chip;change(key==='category'?{categories:state.categories.filter(c=>c!==b.dataset.value)}:key==='date'?{from:-2500,to:2050,before:false,after:false}:key==='collection'||key==='tradition'||key==='language'||key==='type'?{[key]:'All'}:{[key]:''});return;}
 if(b.dataset.action==='reset'){change(C.defaults());showResults();return;}
 if(b.id==='loadMore'){const top=$('bookList').scrollTop;limit+=30;renderBooks();$('bookList').scrollTop=top;}
});
document.addEventListener('change',e=>{if(e.target.dataset.status){const id=e.target.dataset.status,v=e.target.value;if(v)shelf[id]={status:v,rating:shelf[id]?.rating||0};else delete shelf[id];saveShelf();}});
$('categoryChoices').addEventListener('change',()=>change({categories:[...document.querySelectorAll('#categoryChoices input:checked')].map(e=>e.value)}));
for(const [id,key]of [['collectionSelect','collection'],['traditionSelect','tradition'],['languageSelect','language'],['countrySelect','country'],['colorSelect','color'],['sortSelect','sort']])$(id).addEventListener('change',e=>change({[key]:e.target.value}));
for(const [id,key]of [['overlayToggle','overlay'],['unknownToggle','includeUnknown'],['emptyToggle','hideEmpty']])$(id).addEventListener('change',e=>change({[key]:e.target.checked}));
for(const [id,key]of [['fromRange','from'],['fromNumber','from'],['toRange','to'],['toNumber','to']])$(id).addEventListener(id.includes('Range')?'input':'change',e=>{let v=Math.round(+e.target.value/50)*50;v=Math.max(-2500,Math.min(2050,v));if(key==='from')v=Math.min(v,state.to);else v=Math.max(v,state.from);change({[key]:v,before:false,after:false,includeUnknown:false},{keepScroll:true});});
$('resetBtn').onclick=()=>{change(C.defaults());showResults();};$('clearCategories').onclick=()=>change({categories:[]});$('clearPlace').onclick=()=>change({country:''});
$('collapseFilters').onclick=()=>setFilters(false);$('mobileFilters').onclick=()=>setFilters(!filtersOpen);
$('closeResults').onclick=()=>{resultsOpen=false;if(state.view==='books'||state.view==='shelf')change({view:'map'});else{syncPanels();resize();}};$('openResults').onclick=showResults;
$('shelfBtn').onclick=()=>{change({...C.defaults(),view:'shelf'});showResults();};$('themeBtn').onclick=()=>{const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;storageSet('classics-atlas-theme',t);render();};
$('flatBtn').onclick=()=>change({projection:'map'});$('globeBtn').onclick=()=>change({projection:'globe'});
function zoomBy(k){if(state.projection==='globe'){globeScale=Math.max(.6,Math.min(3,globeScale*k));renderMap();}else svg.transition().duration(220).call(zoom.scaleBy,k);}
$('zoomIn').onclick=()=>zoomBy(1.4);$('zoomOut').onclick=()=>zoomBy(1/1.4);$('homeMap').onclick=()=>{rotation=[-10,-20,0];globeScale=1;svg.call(zoom.transform,d3.zoomIdentity);renderMap();};
$('timeExpand').onclick=()=>change({view:state.view==='timeline'?'map':'timeline'});
$('searchForm').onsubmit=e=>{e.preventDefault();const prompt=$('searchInput').value.trim();if(!prompt)return;const result=C.parse(prompt,state);if(result.ok){previous=structuredClone(state);state=result.state;limit=30;render();showResults();}$('replyText').textContent=result.message;$('searchReply').hidden=false;$('undoSearch').disabled=!previous;};
$('undoSearch').onclick=()=>{if(previous){state=previous;previous=null;render();$('replyText').textContent='Previous filters restored.';$('undoSearch').disabled=true;}};$('dismissReply').onclick=()=>$('searchReply').hidden=true;
function about(){$('aboutStats').innerHTML=`<div><strong>${books.length.toLocaleString()}</strong><span>catalog works</span></div><div><strong>${books.filter(b=>b.start!=null).length}</strong><span>dated works</span></div><div><strong>${books.filter(b=>b.countries.length).length}</strong><span>mapped works</span></div><div><strong>${books.filter(b=>b.cover).length}</strong><span>cover matches</span></div>`;$('aboutDialog').showModal();}
for(const id of ['aboutBtn','coverageBtn','dataStatus'])$(id).onclick=about;
$('reduceGlass').onchange=e=>{document.body.classList.toggle('reduced-glass',e.target.checked);storageSet('classics-atlas-reduced-glass',e.target.checked);};
$('shareBtn').onclick=()=>{$('shareHelp').textContent=location.protocol==='file:'?'This portable file is not hosted. Copy this view code; another person with Classics Atlas can paste it here and choose Load this view. Once hosted, this becomes a shareable web link.':'Share this link to open the same filters and timeline. The recipient needs access to this website.';$('shareText').value=location.protocol==='file:'?C.encode(state):location.href.split('#')[0]+C.encode(state);$('shareDialog').showModal();};
$('copyShare').onclick=async()=>{try{await navigator.clipboard.writeText($('shareText').value);toast('Copied. Your reading data is not included.');}catch{$('shareText').select();toast('Select and copy the view code with your keyboard.');}};
$('loadShare').onclick=()=>{const raw=$('shareText').value,hash=raw.includes('#atlas=')?raw.slice(raw.indexOf('#atlas=')):raw;const parsed=C.decode(hash);if(parsed){state=parsed;render();showResults();$('shareDialog').close();toast('Shared view loaded.');}else toast('That is not a valid Classics Atlas view.');};
$('exportShelf').onclick=()=>{const blob=new Blob([JSON.stringify({app:'classics-atlas',version:1,exportedAt:new Date().toISOString(),shelf},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='classics-atlas-shelf.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast('Shelf backup exported.');};
$('importShelf').onclick=()=>$('importFile').click();$('importFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{if(f.size>2e6)throw Error();const raw=JSON.parse(await f.text());if(raw.app!=='classics-atlas'||raw.version!==1||!raw.shelf)throw Error();const incoming=cleanShelf(raw.shelf);shelf={...shelf,...incoming};saveShelf();toast('Imported '+Object.keys(incoming).length+' shelf entries.');}catch{toast('Invalid backup. Your existing shelf is unchanged.');}e.target.value='';};
document.querySelector('.brand').onclick=e=>{e.preventDefault();change(C.defaults());showResults();};
window.addEventListener('resize',()=>{syncPanels();resize();});window.addEventListener('keydown',e=>{if(e.key==='Escape'){setFilters(false);$('searchReply').hidden=true;}});
if(typeof ResizeObserver!=='undefined')new ResizeObserver(resize).observe($('mapCanvas'));
resize();render();
// Read-only diagnostics for automated tests and future integrations.
window.ClassicsAtlas={getState:()=>structuredClone(state),getResults:()=>filtered.map(b=>b.id),getShelf:()=>structuredClone(shelf),catalogSize:books.length};
})();
